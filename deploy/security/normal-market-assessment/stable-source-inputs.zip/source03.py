"""Finite pure adapters for authentic security-source receipts; no live actions.

Caller admission retains source/original descriptors and authenticates the exact
GitHub artifact downloads. ZIP pins below preserve those original artifacts.
This adapter never signs an original, changes an OPEN gate, supplies image-native
proof, grants deployment authority or arms the evidence assessor.
"""
from hashlib import sha256
import io,json,re,zipfile

MAX_INPUT=8*1024**2;MAX_TOTAL=24*1024**2
ASSESSOR_PIN=(21428,'468034ad3ae335efbee0430168bb334d7e5a17a619a555fd73752d3e3e52a040')
FAMILIES={
 'util-linux':{'archive':(2362423,'a53a204c2ad0b04d2526811eaeb2fa40e0799d720c3d57a9650db9ada4279e8b'),
  'receipt':'3a799ad92549c9d3c5e18013463743d9bc2b721eb83557e5ee3a0273d4514dde','schema':'trixie_util_linux_source_candidate/1','members':19,
  'source_version':'2.41.6','source_release':'0+deb13u0+gold1',
  'packages':('bsdutils','libblkid1','liblastlog2-2','libmount1','libsmartcols1','libuuid1','login','mount','util-linux'),
  'advisories':('CVE-2026-76642','CVE-2026-78408','CVE-2026-78410'),
  'recipe':('Dockerfile','build.py','source_regressions.py','verify.py')},
 'ncurses':{'archive':(1319510,'5d4f181112b2965d177c10e3923b2ba2ff4d2b0ee6716818acc9b7f784bfee08'),
  'receipt':'0903c9fbcd69d5dbc6e381f2c84d2718f85899e23c375de2e1c8ec57e81483fd','schema':'trixie_ncurses_vendor_candidate/1','members':11,
  'source_version':'6.6+20260608','source_release':'2~trixie+gold1',
  'packages':('libncursesw6','libtinfo6','ncurses-base','ncurses-bin'),'advisories':('CVE-2025-69720',),'recipe':('Dockerfile','build.py','verify.py')},
 'acl':{'archive':(933904,'d367fb3c1b92f069538a6e90a77ea110efec6dccd9286a8f0e1359b285bc1765'),
  'receipt':'c0114c344ec6103c1d8053421f5e63dc06721b16d8e318f21cde95608d9b465c','schema':'trixie_acl_tar_vendor_candidate/1','members':16,
  'source_version':'2.4.0','source_release':'1~trixie+gold1',
  'packages':('libacl1',),'advisories':('CVE-2026-54369',),'recipe':('Dockerfile','build.py','verify.py')}}
PRIMARY={
 'util-76642.json':(38012,'fb040006758657abaab3d5049a6b33e4ea38180afc75bc0f42af30aba371cbed','CVE-2026-76642','GHSA-m25x-3hj9-m26f'),
 'util-78408.json':(19600,'f6c921fb4ee704d967a4390d2c27620f425f3159d7a5e3e07b18bef748f77c41','CVE-2026-78408','GHSA-55fx-f4gg-cfhj'),
 'util-78409.json':(16375,'37415d0c6ffe9e78fef578fd2a597d4a43c0c8af6ac62dbe12a24824938227a5','CVE-2026-78409','GHSA-8f2p-47x3-43mv'),
 'util-78410.json':(15416,'72bff2ae319b07e4574f62cad71e3ca41b6eb0a625d03e1caca86e8f01b41629','CVE-2026-78410','GHSA-rh77-686x-2f2m'),
 'systemd-16742.json':(22985,'0772911817a6d649948b560eab50256e768872c66e2e63646d5e6dfd2da3ed85','CVE-2026-16742','GHSA-jm29-p7hh-vjhv'),
 'ncurses-69720.html':(4085,'3542be519daaef8f60a0fd662f4a6129a238f59ef9b86155869d49cfd2b3af78','CVE-2025-69720',None),
 'acl-54369.html':(14392,'0dde379d56f30eb4ba3cf30db36253ee1d7e4bfe9780f2b21eb48dcfe29a46a3','CVE-2026-54369',None),
 'perl-9538.html':(6910,'c60b5473f7e62f0b1f9f361cca91eda931bc1c0b5d6bf78b77b8e87edd433478','CVE-2026-9538',None)}
# Genuine fetch interval from retained primary-fetch.json. A fresh review may
# not retimestamp this frozen advisory snapshot beyond its24h validity.
PRIMARY_FETCH_WINDOW=(1793079093,1793165491)
SUBDIR_ZIP=(8496,'d5d733c68d290536f43dfdc68d43360352a956d794924975d7a89478e158d3ac')

class Refused(ValueError):pass
def need(ok,code):
 if not ok:raise Refused(code)
def pin(raw):
 need(type(raw)is bytes and 0<len(raw)<=MAX_INPUT,'input_bound');return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}
def exact(raw,expected):
 need(pin(raw)=={'bytes':expected[0],'sha256':expected[1]},'original_pin')
def inputs(raws):
 need(type(raws)is dict and 0<len(raws)<=32 and all(type(k)is str and re.fullmatch('[A-Za-z0-9_.-]{1,128}',k)for k in raws),'input_names')
 result={k:pin(v)for k,v in raws.items()};need(sum(v['bytes']for v in result.values())<=MAX_TOTAL,'aggregate_bound');return result
def archive(raw,expected,members):
 exact(raw,expected);z=zipfile.ZipFile(io.BytesIO(raw));infos=z.infolist()
 need(len(infos)==members and len({i.filename for i in infos})==members and sum(i.file_size for i in infos)<=16*1024**2,'archive_inventory')
 for item in infos:
  need(re.fullmatch('[A-Za-z0-9_.+~-]{1,128}',item.filename)and not item.is_dir()and not item.flag_bits&1 and item.file_size<=4*1024**2,'archive_member')
 return z

def primary_facts(A,raws):
 need(type(raws)is dict and set(raws)==set(PRIMARY),'primary_inventory')
 for name,(size,digest,cve,ghsa)in PRIMARY.items():
  raw=raws[name];exact(raw,(size,digest))
  if ghsa:
   doc=A.document(raw);need(doc.get('state')=='published'and doc.get('cve_id')==cve and doc.get('ghsa_id')==ghsa,'primary_identity')
   namespace='systemd/systemd'if name.startswith('systemd-')else'util-linux/util-linux'
   need(doc.get('html_url')=='https://github.com/'+namespace+'/security/advisories/'+ghsa,'primary_origin')
   vulnerable=doc.get('vulnerabilities');need(type(vulnerable)is list and len(vulnerable)==1,'primary_versions')
   component=vulnerable[0]
   if name.startswith('util-'):
    need(component['package']['name']=='util-linux'and component['patched_versions']=='2.41.6; 2.42.3','primary_versions')
    if cve=='CVE-2026-78409':need(component['vulnerable_version_range']=='>=2.42','primary_versions')
   else:need(component['package']['name']=='systemd-homed'and 'systemd-homework'in doc['description'],'primary_component')
  else:
   text=raw.decode('utf-8');need(cve in text,'primary_identity')
   if name=='ncurses-69720.html':need('6.6+20260608-2'in text and '6.5-20251213'in text and 'infocmp'in text,'primary_versions')
   elif name=='acl-54369.html':need('acl-2.4.0'in text and 'acl_get_file_at()'in text and 'each individual program'in text,'primary_callers')
   else:need('Archive::Tar'in text and '3.10'in text and 'CPAN Security Group'in text,'primary_component')
 return {'official_sources_reviewed':True,'advisory_ids':sorted(r[2]for r in PRIMARY.values())}

def receipt(A,family,raws):
 need(family in FAMILIES,'family');spec=FAMILIES[family]
 need(set(raws)=={'candidate.zip',*('recipe-'+n for n in spec['recipe'])},'family_inputs')
 inputs(raws)
 with archive(raws['candidate.zip'],spec['archive'],spec['members'])as z:
  def read(name,maximum):
   info=z.getinfo(name);need(0<info.file_size<=maximum,'member_bound');raw=z.read(info);need(len(raw)==info.file_size,'member_bound');return raw
  original=read('build-receipt.json',65536);need(sha256(original).hexdigest()==spec['receipt'],'receipt_pin');r=A.document(original)
  need(r['schema']==spec['schema']and r['status']=='candidate_built_not_accepted'and r['maintainer_signatures_authenticated']is False
   and all(r[k]is False for k in('production_installed','raw_scanner_gate_waived','security_accepted')),'receipt_boundary')
  recipe=A.document(read('recipe-identity.json',65536));need(recipe['recipe_sha256']==r['recipe_sha256']and set(r['recipe_sha256'])==set(spec['recipe']),'recipe_identity')
  for name in spec['recipe']:need(sha256(raws['recipe-'+name]).hexdigest()==r['recipe_sha256'][name],'recipe_pin')
  for item in r['build_records']:need(sha256(read(item['path'],65536)).hexdigest()==item['sha256'],'build_record_pin')
  need(r['abi']['status']=='passed'and all(v['status']=='passed'and type(v['old_exports_retained'])is int and v['old_exports_retained']>0 for v in r['abi']['libraries'].values()),'abi_not_verified')
  if family=='util-linux':
   need(r['version']=='2.41.6-0+deb13u0+gold1'and r['services_changed']is False,'source_version')
   old=r['source_regressions'];need(old['CVE-2026-78409_vendor_binary_reconciliation']=='OPEN'and old['compiled_contracts']=='passed'
    and old['privileged_cgroup_namespace_credential_drop']=='NOT_TESTED'and old['privileged_failed_helper_ownership']=='NOT_TESTED','preserve_historical_open')
   need(r['upstream_suite']['status']=='passed'and r['upstream_suite']['skips_are_not_privileged_coverage']is True,'upstream_suite')
   need(set(r['selected_runtime_packages'])==set(spec['packages']),'package_inventory')
   for key in ('build-provenance.json','source-tests.json'):
    doc=A.document(read(key,65536))
    if key=='build-provenance.json':need(doc['compiled_in_this_run']is False and doc['reused_receipt_sha256']==spec['receipt'],'original_compile_provenance')
    else:need(doc==old,'source_tests')
  elif family=='ncurses':
   need(r['version']=='6.6+20260608-2~trixie+gold1'and r['vendor_source_version']=='6.6+20260608-2'
    and r['source_authentication']=='signed_debian_snapshot_sources_index_and_pinned_archive_bytes'
    and r['vendor_package_build']=='passed'and r['abi']['ordinary_functional_compatibility']=='passed'
    and r['interactive_upstream_suite']=='NOT_TESTED','vendor_source')
   need(set(r['selected_runtime_packages'])==set(spec['packages']),'package_inventory')
  else:
   need(r['source_authentication']=='signed_debian_snapshot_sources_index_and_pinned_archive_bytes'and r['legacy_file_api_security_assessed']is False
    and r['acl_compiler_provenance']['library_sha256']==r['abi']['libraries']['acl']['candidate_library_sha256'],'acl_library_only')
   original_acl=read('acl-build-receipt.json',65536);need(sha256(original_acl).hexdigest()==r['acl_build_receipt_sha256'],'acl_source_receipt')
  packages=[]
  for name in spec['packages']:
   matches=[q for q in r['all_family_packages']if q['name']==name];need(len(matches)==1,'package_inventory');item=matches[0]
   raw=read(item['path'],2*1024**2);need(len(raw)==item['bytes']and sha256(raw).hexdigest()==item['sha256'],'package_deb_pin')
   version=spec['source_version']+'-'+spec['source_release']
   if name=='bsdutils':version='1:'+version
   elif name=='login':version='1:4.16.0-2+really'+version
   need(item['version']==version,'package_epoch_version')
   packages.append({'package':name,'installed_version':version,'deb_sha256':item['sha256']})
 return {'advisory_ids':list(spec['advisories']),'source_package':family,'source_version':spec['source_version'],'source_release':spec['source_release'],
  'source_verified':True,'build_abi_verified':True,'packages':packages}

def source_facts(A,family,raws,scan_raw,sbom_raw,scope):
 A.scope(scope);facts=receipt(A,family,raws);rows,_=A.findings(A.document(scan_raw),A.document(sbom_raw),scope)
 # Each exactly declared package must exist in the current, unmodified image's
 # scanner/SBOM join. This is not the separate installed-payload/native proof.
 current=[r for r in rows if r['source_package']==family];spec=FAMILIES[family]
 need({r['package']for r in current}==set(spec['packages']),'current_package_inventory')
 for row in current:
  need(all(row[k]==facts[k]for k in ('source_package','source_version','source_release')),'current_source')
  need(any(row['package']==p['package']and row['installed_version']==p['installed_version']for p in facts['packages']),'current_version')
 need(set(facts['advisory_ids'])<={r['advisory']for r in current},'current_advisory')
 return facts

def subdir_absence_facts(A,proof_zip,util_raws,primary_raws):
 # A NEW source-path absence proof; never a relabelled successful vendor check.
 primary_facts(A,primary_raws);receipt(A,'util-linux',util_raws)
 with archive(proof_zip,SUBDIR_ZIP,15)as z:
  def read(name,maximum):
   info=z.getinfo(name);need(info.file_size<=maximum,'member_bound');return z.read(info)
  p=A.document(read('proof.json',65536));need(p['schema']=='util_linux_restricted_subdir_contract/1'
   and p['status']=='source_contract_passed_not_accepted'and p['advisory']=='CVE-2026-78409'
   and p['historical_build_receipt_sha256']==FAMILIES['util-linux']['receipt']and p['restricted_refusal_before_stub_side_effects']is True,'subdir_contract')
  need(p['libmount_package']=={'path':'libmount1_2.41.6-0+deb13u0+gold1_amd64.deb','bytes':210776,'sha256':'111baa6313bd1e72002d99725bf2f82e07d8dafd282269e005d5600aa616aaca'},'subdir_package')
  for key in ('vendor_database_reconciliation_completed','privileged_or_kernel_mount_operations_executed','historical_receipts_modified','scanner_findings_modified','production_installed','security_accepted','maintainer_signatures_authenticated'):need(p[key]is False,'subdir_boundary')
  expected={f'mountfd-{mode}-{variant}'for mode in('enabled','disabled')for variant in('original','missing-guard')}
  need(set(p['compiled_contracts'])==expected,'subdir_profiles')
  for name,row in p['compiled_contracts'].items():
   need(type(row['compile']['exit_code'])is int and row['compile']['exit_code']==0 and type(row['run']['exit_code'])is int
    and row['run']['exit_code']==(10 if name.endswith('missing-guard')else 0),'subdir_exits')
   need(sha256(read(name+'.c',65536)).hexdigest()==row['fixture_source_sha256'],'subdir_fixture')
 return {'advisory_ids':['CVE-2026-78409'],'component':'restricted_user_detached_tree_fast_path','absent':True,'inventory_complete':True,
  'unreadable_inputs':0,'limit_exceeded':False,'scope':'stable_source_vulnerable_path_absent'}

def _envelope(A,kind,scope,observations,originals,producer_raw,*,completed_at,finalizer,namespace=None):
 """Only Root's retained original-input finalizer can finish publication input.

 This helper does not create an armed lock or accept any finding. The real
 caller must authenticate original downloads and producer source, use its real
 clock, retain descriptor identities through every physical close and separately
 provide the assessor's native/caller/mandatory proofs.
 """
 need(kind in {'source_backport','component_absence','advisory_review'},'proof_kind');A.scope(scope)
 if namespace is not None:
  need(type(namespace)is str and re.fullmatch('[a-z][a-z0-9_-]{0,31}',namespace),'namespace')
  originals={namespace+'.'+key:raw for key,raw in originals.items()}
 pins=inputs(originals)
 need(type(completed_at)is int and PRIMARY_FETCH_WINDOW[0]<=completed_at<=PRIMARY_FETCH_WINDOW[1] and callable(finalizer),'completion_contract');source=pin(producer_raw)
 value={'schema':'image_security_evidence_proof/1','kind':kind,'scope':scope,'producer_sha256':source['sha256'],
  'original_inputs':pins,'completed_at':completed_at,'observations':observations}
 need(len(A.encoded(value))<=MAX_INPUT,'output_bound');result=finalizer();need(result is None or result is True,'finalizer_failed');return value


def produce(A,kind,scope,originals,producer_raw,*,completed_at,finalizer,family=None,namespace=None):
 """Closed entry point; observations are derived, never caller-supplied JSON."""
 need(namespace is None or type(namespace)is str and re.fullmatch('[a-z][a-z0-9_-]{0,31}',namespace),'namespace')
 inputs(originals);A.scope(scope);need('assessor.py'in originals,'assessor_dependency');exact(originals['assessor.py'],ASSESSOR_PIN)
 primary={name:originals[name]for name in PRIMARY if name in originals}
 advisory=primary_facts(A,primary)
 if kind=='advisory_review':
  need(family is None and set(originals)==set(PRIMARY)|{'assessor.py'},'proof_inputs');facts=advisory
 elif kind in {'source_backport','component_absence'}:
  need(family in FAMILIES and (kind!='component_absence'or family=='util-linux'),'family')
  names={'candidate.zip',*('recipe-'+n for n in FAMILIES[family]['recipe'])}
  expected=set(PRIMARY)|names|{'scan.json','sbom.json','assessor.py'}
  if kind=='component_absence':expected.add('subdir.zip')
  need(set(originals)==expected,'proof_inputs');raws={k:originals[k]for k in names}
  facts=source_facts(A,family,raws,originals['scan.json'],originals['sbom.json'],scope)
  if kind=='component_absence':facts=subdir_absence_facts(A,originals['subdir.zip'],raws,primary)
 else:raise Refused('proof_kind')
 return _envelope(A,kind,scope,facts,originals,producer_raw,completed_at=completed_at,finalizer=finalizer,namespace=namespace)
