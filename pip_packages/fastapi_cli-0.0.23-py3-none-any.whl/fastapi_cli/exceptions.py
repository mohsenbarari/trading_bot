class FastAPICLIException(Exception):
    pass
